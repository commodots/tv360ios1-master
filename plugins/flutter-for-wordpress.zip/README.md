# Flutter for wordpress wp plugin

The wordpress plugin for flutter for wordpress app. Install this plugin before you setup your flutter app.

